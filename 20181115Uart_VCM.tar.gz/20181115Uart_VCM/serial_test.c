// this exmaple is used for communation between linux and arduino.
//AUTHOR : CHEN ZENGHUI
//DATE : 2018-11-15 11:14
//VERSION: 1.0

#include <stdio.h>
#include <termios.h> 
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <math.h>

#define Baudrate B9600
#define Serial_Port "/dev/ttyUSB0"
#define false 0
#define true 1
#define uint unsigned int
#define MAX_SIZE 32    //数组长度

 //十进制数字转换成十六进制字符串
char * num2hex(uint num)
{
    int i;
    uint tmp;
 
    uint mask = 0x000f;            //掩码0x 0000 000f
    
   static char hex[MAX_SIZE];  //存储十六进制字符串
 
    hex[0] = '0';               //前两位固定不变，为0x
    hex[1] = 'X'; 
    hex[2] = '0';
    //为其余元素赋值
    for(i = 5; i >= 3; i--)
    {
        tmp = num & mask;
	    hex[i] = (tmp >= 10) ? ((tmp - 10)  + 'A') : (tmp + '0'); 
	    num  = num >> 4;
    }
 
    return hex;
}

//字符串转换成16进制 
/*inline char *CharArrayToHexString(char* pOut, const int nMaxLen, const char* pInput, const int nInLen) 
{ 
const char* chHexList = "0123456789ABCDEF"; 
int nIndex = 0; 
int i=0, j=0; 
for (i=0, j=0;i<nInLen;i++, j+=2)
 { 
    nIndex = (pInput[i] & 0xf); pOut[i*2+1] = chHexList[nIndex];
    nIndex = ((pInput[i]>>4) & 0xf); 
    pOut[i*2] = chHexList[nIndex]; 
  } 
    return pOut; 
}*/





int main(int argc, char *argv[])
{
     int serial_fd;
     int serial_read_ret, serial_write_ret;
   //  char serial_buffer_send[] = "AA01020103E87517";
      char serial_buffer_send[]={0XAA,0X01,0X02,0X01,0X03,0XE8,0X75,0X17};
    // char serial_buffer_revent[] = {0X0,0X0,0X0,0X0,0X0,0X0,0X0,0X0};
     char serial_buffer_recv[] = {0X0,0X0,0X0,0X0,0X0,0X0,0X0,0X0};

//定义自动相机模块控制协议，电机复位命令和电机反转命令
      char Motor_reset[8] = {0};  //电机复位
      Motor_reset[0] = 0xAA;  //起始位
      Motor_reset[1] = 0x01;  //地址码
      Motor_reset[2] = 0x05;  //命令吗
      Motor_reset[3] = 0x01;  //数据个数
      Motor_reset[4] = 0x00;  //数据高字节
      Motor_reset[5] = 0x00;  //数据低字节
      Motor_reset[6] = 0x74;  //CRC低字节
      Motor_reset[7] = 0xDD;  //CRC高字节

      char Motor_work_on[8] = {0};  //电机反转
      Motor_work_on[0] = 0xAA;
      Motor_work_on[1] = 0x01;
      Motor_work_on[2] = 0x02;
      Motor_work_on[3] = 0x01;
      Motor_work_on[4] = 0x00;  
      Motor_work_on[5] = 0x00;
      Motor_work_on[6] = 0x00;
      Motor_work_on[7] = 0x00;

      char CRC_buf[6] = {0};
      /*CRC_buf[0] = Motor_work_on[0];
      CRC_buf[1] = Motor_work_on[1];
      CRC_buf[2] = Motor_work_on[2];
      CRC_buf[3] = Motor_work_on[3];
      CRC_buf[4] = Motor_work_on[4];
      CRC_buf[5] = Motor_work_on[5];*/


     int pulse = 0;  //定义要输入电机走的脉冲数目，该值要小于960

     bool init_flag = false;//定义初始化标志位
     
     
     


     int buf[512] = {0};
     float sum = 0;
     bool flag = false;
     int count =0;


     struct termios tty;
     int fd = open(Serial_Port, O_RDWR | O_NOCTTY);
     if(fd == -1)
      {
        perror("cant't open port!\n");
        exit(1);
      }
      else 
      {
      printf("open port sucessfully!\n");
      }

      bzero(&tty, sizeof(tty));
      tcflush(fd, TCIOFLUSH);

      cfsetospeed (&tty, Baudrate);
      cfsetispeed (&tty, Baudrate);

      tty.c_cflag &= ~PARENB; // Make 8n1
      tty.c_cflag &= ~CSTOPB;
      tty.c_cflag &= ~CSIZE;
      tty.c_cflag |= CS8;
      tty.c_cflag &= ~CRTSCTS; // no flow control
      tty.c_lflag = 0; // no signaling chars, no echo, no canonical processing
      tty.c_oflag = 0; // no remapping, no delays
      tty.c_cc[VMIN] = 0; // read block
      tty.c_cc[VTIME] = 1; // 0.5 seconds read timeout

      tty.c_cflag |= CREAD | CLOCAL; // turn on READ & ignore ctrl lines
      tty.c_iflag &= ~(IXON | IXOFF | IXANY); // turn off s/w flow ctrl
      tty.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG); // make raw
      tty.c_oflag &= ~OPOST; // make raw
    
      if (tcsetattr (fd, TCSANOW, &tty) != 0)
      {
      printf("@@@@@@@串口设置失败！@@@@@@@\n");
      }
      else
    {
       printf("@@@@@@@串口设置成功！@@@@@@@\n");
      while(true)
{    
      if(init_flag == true)   //电机复位指令
      {
      int nLent_Motor_reset = strlen(Motor_reset);
      printf("nLent_Motor_reset is %d\n",nLent_Motor_reset);
      serial_write_ret = write(fd,Motor_reset,nLent_Motor_reset);
      printf("@@@@@@@自动相机模块电机复位！@@@@@@@\n");
      printf("@@@@@@@电机复位指令为@@@@@@@\n");

      int k;
      for(k= 0;k<8;k++)
      {
      printf(" Motor_reset[%d]  is %X\n ",k,Motor_reset[k]);
      }
 
      }

      init_flag = true;  //从第二次开始用命令来控制电机复位

      printf("请输入电机要走的Pulses数目：\n");
      scanf("Pulses = %d\n",&pulse);
      printf("Pulses is %d\n",pulse);

      Motor_work_on[4] = (pulse/256) & 0xFF;  
      Motor_work_on[5] = (pulse%256) & 0xFF;
      
   /*   char * tmp;
     // int num;
      char dis[6] = "";
      //十进制数转化为十六进制字符
      char data_H[] = "0X00";   //数据位高位
      char data_L[] = "0X00";   //数据位地位

      tmp = num2hex(pulse);
      printf("%d to hex is %s\n", pulse, tmp);

      int j;
      for(j =0 ; j< 6; j++)
      {
       dis[j] = *(tmp++);
      }
      printf("%s\n",dis);

  
      data_H[2] = dis[2];
      data_H[3] = dis[3];
      data_L[2] = dis[4];
      data_L[3] = dis[5];
  
      printf("%d 数据高字节为 %s\n", pulse, data_H);
      printf("%d 数据低字节为 %s\n", pulse, data_L);


//Motor_work_on Data数据位替换  将字符串转化成16进制数
     // Motor_work_on[4] = data_H[0];  
      //Motor_work_on[5] = data_L[0];
    //strcpy(Motor_work_on[4],data_H[0]);
    //strcpy(Motor_work_on[5],data_L[0]);*/
     printf("请核查制定秒钟对应的电机输入指令（前6位数据位）：\n");
     int j;
     for(j= 0;j<6;j++)
     {
     printf(" Motor_work_on[%d] after replacing is %X\n ",j,Motor_work_on[j]);
     }

      CRC_buf[0] = Motor_work_on[0];
      CRC_buf[1] = Motor_work_on[1];
      CRC_buf[2] = Motor_work_on[2];
      CRC_buf[3] = Motor_work_on[3];
      CRC_buf[4] = Motor_work_on[4];
      CRC_buf[5] = Motor_work_on[5];

     for(j= 0;j<8;j++)
     {
     printf(" CRC_buf[%d] after replacing is %d\n ",j,CRC_buf[j]);
     }

//CRC(MODBUS)校验

    unsigned short tmp_crc = 0xFFFF;
    unsigned short ret1 = 0;
    unsigned short ret2 = 0;
    int n;
    for(n = 0; n < 6; n++){/*此处的6 -- 要校验的位数为6个*/
        tmp_crc = CRC_buf[n] ^ tmp_crc;
        int i;
        for( i = 0;i < 8;i++){  /*此处的8 -- 指每一个char类型又8bit，每bit都要处理*/
            if(tmp_crc & 0x01){
                tmp_crc = tmp_crc >> 1;
                tmp_crc = tmp_crc ^ 0xa001;
            }   
            else{
                tmp_crc = tmp_crc >> 1;
            }   
        }   
    }   
    /*CRC校验后的值*/
    printf("%X\n",tmp_crc);
    /*将CRC校验的高低位对换位置*/
    ret1 = tmp_crc >> 8;
    printf("高位ret1: %X\n",ret1);
    ret1 = ret1 | (tmp_crc << 8); 
    ret2 = ret1 >> 8;
    printf("低位ret2: %X\n",ret2); 

//Motor_work_on Data数据位补全 
     Motor_work_on[6] = ret2 & 0xFF; 
     Motor_work_on[7] = ret1 & 0xFF;

     printf("请核查指定脉冲对应的电机输入指令（前8位数据位）：\n");                   
     for(j= 0;j<8;j++)
     {
     printf(" CRC_buf[%d] after replacing is %d\n ",j,CRC_buf[j]);
     }

     int nLent_Motor_work_on = strlen(Motor_work_on);
     printf("nLent_Motor_work_on is %d\n",nLent_Motor_work_on);
     serial_write_ret = write(fd,Motor_work_on,nLent_Motor_work_on);
     printf("@@@@@@@自动相机模块电机运动！@@@@@@@\n");
     sleep(1);

     printf("请按任意键回车以继续。。。。。");
     char c;
     c = getchar();
     sleep(1);
    








}
      /* int nLent = strlen(serial_buffer_send);
       printf("%d\n",nLent);
 
       serial_write_ret = write(fd,serial_buffer_send,strlen(serial_buffer_send));
      for(int i=0;i<strlen(serial_buffer_send);i++)
       {
      printf("Sent to serial port: %c\n",serial_buffer_send[i]);
       }
       
      serial_read_ret = read(fd,serial_buffer_recv,sizeof(serial_buffer_recv));
      
      if(serial_read_ret < 1)
       {
       printf("无数据返回！\n");
       }
      else
       {
       printf("Read from serial port: %s\n",serial_buffer_recv);
       
       }*/
        
        
     }

      close(fd);
      return 0;

}
